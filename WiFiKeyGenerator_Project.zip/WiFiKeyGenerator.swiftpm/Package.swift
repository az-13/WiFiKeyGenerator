// swift-tools-version: 5.6
import PackageDescription

let package = Package(
    name: "WiFiKeyGenerator",
    platforms: [
        .iOS("15.2")
    ],
    products: [
        .iOSApplication(
            name: "WiFiKeyGenerator",
            targets: ["AppModule"],
            bundleIdentifier: "com.business.WiFiKeyGenerator",
            teamIdentifier: "",
            displayVersion: "1.0",
            bundleVersion: "1",
            iconAssetName: "AppIcon",
            accentColorAssetName: "AccentColor",
            supportedDeviceFamilies: [
                .pad,
                .phone
            ],
            supportedInterfaceOrientations: [
                .portrait,
                .landscapeRight,
                .landscapeLeft,
                .portraitUpsideDown(.when(deviceFamilies: [.pad]))
            ]
        )
    ],
    targets: [
        .executableTarget(
            name: "AppModule",
            path: ".",
            resources: [
                .process("Resources")
            ]
        )
    ]
)
