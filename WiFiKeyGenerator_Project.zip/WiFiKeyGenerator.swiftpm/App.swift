import SwiftUI

@main
struct WiFiKeyGeneratorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
